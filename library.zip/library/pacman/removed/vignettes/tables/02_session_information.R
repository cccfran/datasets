| pacman Function | Base Equivalent | Description |
|----------------------|----------------------|----------------|
| `p_loaded`  |  `.packages` & `sessionInfo` | List Attached Packages |
| `p_isloaded`  |  NONE | Logical Test of Attached Package |